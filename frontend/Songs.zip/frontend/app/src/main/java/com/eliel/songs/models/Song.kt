package com.eliel.songs.models

data class Song (val id: Int, val name: String, val artist: String, val lenght: String, val year: String)